import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is a world where cats eat pizza that falls from the sky.
 */
public class CatWorld  extends World
{
    /**
     * CatWorld Constructor.
     */
    public CatWorld()
    {    
        super(700, 500, 1); 
    }

}
