import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Enemies are bad news for Mario.
 * 
 * YOUR NAME
 * TODAY'S DATE
 * 
 */
public class Enemy extends Actor
{
    /**
     * Enemy Constructor
     * Set the initial Image to boo.png
     */
    public Enemy()
    {
        setImage("boo.png");
    }
    /**
     * Make the Enemies do things
     */
    public void act() 
    {
        
    }    
}
