
public class __SHELL11 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("/Volumes/GoogleDrive/My Drive/ICS/Greenfoot/piano 2");
final Piano piano = (Piano)__bluej_runtime_scope.get("piano");


piano.playNotes();

}}
