import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Coins are for Mario to take!
 * 
 * YOUR NAME
 * TODAY'S DATE
 * 
 */
public class Coin extends Actor
{
    /**
     * Coin Constructor
     * Make it look like a coin.
     */
    public Coin()
    {
        setImage("coin.png");
    }
    
    /**
     * Make the coins do things???
     */
    public void act() 
    {
       
    }    
}
