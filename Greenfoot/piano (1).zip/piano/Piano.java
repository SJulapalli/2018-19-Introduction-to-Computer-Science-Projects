import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

//Piano Project

public class Piano extends World
{
    public Piano() //Piano Constructor
    {
        super(800, 340, 1);
    }
}